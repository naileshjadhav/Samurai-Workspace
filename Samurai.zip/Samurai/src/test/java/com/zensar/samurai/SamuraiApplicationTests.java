package com.zensar.samurai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamuraiApplicationTests {

	@Test
	void contextLoads() {
	}

}
