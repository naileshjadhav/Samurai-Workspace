package com.zensar.SamuraiZenAnalyticaIntegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamuraiZenAnalyticaIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamuraiZenAnalyticaIntegrationApplication.class, args);
	}

}
