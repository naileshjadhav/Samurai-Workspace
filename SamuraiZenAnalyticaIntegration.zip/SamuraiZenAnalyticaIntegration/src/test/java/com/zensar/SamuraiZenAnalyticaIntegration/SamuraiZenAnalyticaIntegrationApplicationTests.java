package com.zensar.SamuraiZenAnalyticaIntegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamuraiZenAnalyticaIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
