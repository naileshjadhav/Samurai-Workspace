package com.zensar.samurai.model;

public class ZenAnalyticaDTO {
	
	public String event;

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}
	
	

}
