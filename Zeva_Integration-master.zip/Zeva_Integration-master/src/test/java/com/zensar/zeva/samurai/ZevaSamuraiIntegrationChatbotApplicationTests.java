package com.zensar.zeva.samurai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZevaSamuraiIntegrationChatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
