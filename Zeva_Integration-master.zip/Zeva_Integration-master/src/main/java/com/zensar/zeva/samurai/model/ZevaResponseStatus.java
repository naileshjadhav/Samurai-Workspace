package com.zensar.zeva.samurai.model;

public class ZevaResponseStatus {

	private Integer code;
	private String errorType;

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

}
